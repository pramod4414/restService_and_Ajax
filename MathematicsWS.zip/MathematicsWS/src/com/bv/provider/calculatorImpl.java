package com.bv.provider;

import javax.jws.WebService;

@WebService(endpointInterface="com.bv.provider.Calculator")
public class calculatorImpl implements Calculator {

	private double ans;

	@Override
	public double add(double a, double b) {
		ans=a+b;
		return ans;
	}

	@Override
	public double sub(double a, double b) {
		ans=a-b;
		return ans;
	}

	@Override
	public double div(double a, double b) {
		ans=a/b;
		return ans;
	}

	@Override
	public double multiply(double a, double b) {
		ans=a*b;
		return ans;
	}

}
