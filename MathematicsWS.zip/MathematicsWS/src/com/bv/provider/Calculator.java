package com.bv.provider;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

@WebService
@SOAPBinding
public interface Calculator {
	@WebMethod
	public double add(double a, double b);
	@WebMethod
	public double sub(double a, double b);
	@WebMethod
	public double div(double a, double b);
	@WebMethod
	public double multiply(double a, double b);

}
