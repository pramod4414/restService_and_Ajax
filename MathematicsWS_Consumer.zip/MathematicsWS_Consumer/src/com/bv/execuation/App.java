package com.bv.execuation;

import com.bv.provider.Calculator;
import com.bv.provider.CalculatorImplService;

public class App {
	public static void main(String[] args) {
		
		CalculatorImplService service = new CalculatorImplService();
		Calculator obj = service.getCalculatorImplPort();
		System.out.println(obj.add(5, 6));
		System.out.println(obj.sub(10, 6));
		System.out.println(obj.div(15, 6));
		System.out.println(obj.multiply(5, 6));
		
	}

}
