@javax.xml.bind.annotation.XmlSchema(namespace = "http://provider.bv.com/")
package com.bv.provider;
